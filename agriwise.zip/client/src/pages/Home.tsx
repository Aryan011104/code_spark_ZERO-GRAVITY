import { useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Check,
  ChevronDown,
  CircleHelp,
  CloudSun,
  Droplets,
  FlaskConical,
  Leaf,
  Menu,
  Mic,
  MoreHorizontal,
  Play,
  Send,
  ShieldCheck,
  Sprout,
  SunMedium,
  ThermometerSun,
  ThumbsDown,
  ThumbsUp,
  Volume2,
  Wind,
  X,
} from "lucide-react";

type Crop = "Coffee" | "Potato" | "Maize";
type Language = "English" | "Swahili" | "Kikuyu";
type Soil = { n: string; p: string; k: string; ph: string; om: string };
type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((event: { results: { [index: number]: { [index: number]: { transcript: string } } } }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
};

const cropData: Record<Crop, {
  note: string;
  formula: string;
  dose: string;
  organic: string;
  confidence: string;
  npk: [number, number, number];
  rationale: string;
}> = {
  Coffee: {
    note: "Flowering window",
    formula: "14-14-14 + compost",
    dose: "34 kg / acre",
    organic: "4 bags compost / acre",
    confidence: "92%",
    npk: [78, 64, 56],
    rationale: "Potassium is slightly low for the flowering window. A balanced base keeps leaf growth steady without pushing excess nitrogen.",
  },
  Potato: {
    note: "Bulking window",
    formula: "12-12-17 + Mg",
    dose: "41 kg / acre",
    organic: "3 bags compost / acre",
    confidence: "89%",
    npk: [62, 58, 81],
    rationale: "Your crop stage calls for more potassium than nitrogen. The mix supports tuber bulking while keeping the soil pH in range.",
  },
  Maize: {
    note: "Early vegetative",
    formula: "23-10-5 + urea",
    dose: "29 kg / acre",
    organic: "2 bags compost / acre",
    confidence: "94%",
    npk: [84, 51, 48],
    rationale: "Nitrogen demand is rising, but phosphorus remains the limiting nutrient. Split the dose to reduce runoff and protect soil biology.",
  },
};

const languageResponses: Record<Language, string> = {
  English: "For this plot, apply the recommended NPK mix after the next light rain. Keep a 10 cm ring clear around the coffee stem, then cover with mulch.",
  Swahili: "Kwa shamba hili, tumia mchanganyiko wa NPK uliopendekezwa baada ya mvua nyepesi inayofuata. Acha nafasi ya sentimita 10 kuzunguka shina na funika kwa matandazo.",
  Kikuyu: "Kũu gĩthaka-inĩ, thomera NPK ĩrĩa tũrĩmĩte thuutha wa mbura nĩĩrĩa ĩgũkũrũka. Tiga handũ ha sentimita 10 kũrĩ rũhĩa, ũgĩcokerere na mulch.",
};

function LeafMark({ small = false }: { small?: boolean }) {
  return (
    <div className={`leaf-mark ${small ? "leaf-mark-small" : ""}`} aria-hidden="true">
      <Leaf size={small ? 17 : 21} strokeWidth={2.2} />
      <span />
    </div>
  );
}

function Sidebar({ active, onNavigate, open, onClose }: { active: string; onNavigate: (value: string) => void; open: boolean; onClose: () => void }) {
  const links = [
    { label: "Field workspace", icon: Sprout },
    { label: "Ask AgriWise", icon: Volume2 },
    { label: "My soil notes", icon: FlaskConical },
    { label: "Evaluations", icon: BarChart3 },
  ];

  return (
    <>
      {open && <button className="mobile-scrim" aria-label="Close menu" onClick={onClose} />}
      <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
        <div className="brand-lockup">
          <LeafMark />
          <div>
            <div className="wordmark">AgriWise</div>
            <div className="brand-caption">field intelligence</div>
          </div>
          <button className="icon-button mobile-close" onClick={onClose} aria-label="Close menu"><X size={17} /></button>
        </div>

        <div className="farm-switcher">
          <div className="farm-avatar">AM</div>
          <div className="farm-copy"><strong>Amina's plot</strong><span>Kiambu · 0.8 acre</span></div>
          <ChevronDown size={15} className="muted-icon" />
        </div>

        <div className="nav-group-label">Workspace</div>
        <nav className="sidebar-nav" aria-label="Primary">
          {links.map(({ label, icon: Icon }) => (
            <button key={label} className={`nav-link ${active === label ? "nav-link-active" : ""}`} onClick={() => { onNavigate(label); onClose(); }}>
              <Icon size={17} strokeWidth={1.9} />
              <span>{label}</span>
              {label === "Ask AgriWise" && <span className="new-dot" />}
            </button>
          ))}
        </nav>

        <div className="sidebar-spacer" />

        <div className="voice-prompt">
          <div className="voice-prompt-icon"><Mic size={17} /></div>
          <strong>Prefer to speak?</strong>
          <span>Ask in your language with voice.</span>
          <button className="text-button" onClick={() => onNavigate("Ask AgriWise")}>Try voice <ArrowUpRight size={13} /></button>
        </div>

        <div className="sidebar-footer">
          <button className="footer-link"><CircleHelp size={15} /> Help center</button>
          <button className="footer-link"><MoreHorizontal size={15} /> Settings</button>
        </div>
      </aside>
    </>
  );
}

function WeatherCard() {
  return (
    <section className="weather-card">
      <div className="section-eyebrow"><CloudSun size={15} /> Live field conditions</div>
      <div className="weather-main">
        <div><span className="weather-temp">23°</span><span className="weather-unit">C</span></div>
        <div className="weather-icon-wrap"><CloudSun size={32} strokeWidth={1.4} /></div>
      </div>
      <div className="weather-place">Kiambu County <span>·</span> 10:42 AM</div>
      <div className="weather-metrics">
        <div><Droplets size={14} /><span>68% humidity</span></div>
        <div><Wind size={14} /><span>8 km/h wind</span></div>
      </div>
      <div className="rain-callout"><div className="rain-bar" /><div><strong>Light rain likely</strong><span>Tomorrow, 6–9 AM · good for application</span></div></div>
    </section>
  );
}

function SoilInputCard({ crop, setCrop, soil, setSoil, onAnalyze, analyzing }: { crop: Crop; setCrop: (crop: Crop) => void; soil: Soil; setSoil: (soil: Soil) => void; onAnalyze: () => void; analyzing: boolean }) {
  const fields = [
    { key: "n", label: "Nitrogen", short: "N", unit: "mg/kg", color: "green" },
    { key: "p", label: "Phosphorus", short: "P", unit: "mg/kg", color: "orange" },
    { key: "k", label: "Potassium", short: "K", unit: "mg/kg", color: "blue" },
    { key: "ph", label: "Soil pH", short: "pH", unit: "0–14 scale", color: "brown" },
    { key: "om", label: "Organic matter", short: "OM", unit: "%", color: "green" },
  ] as const;

  return (
    <section className="panel soil-card" id="soil-notes">
      <div className="panel-heading">
        <div><div className="section-eyebrow">01 · Soil snapshot</div><h2>What is your field telling you?</h2><p>Use your latest test results. We’ll keep the recommendation specific to this plot.</p></div>
        <button className="help-icon" aria-label="About soil readings"><CircleHelp size={16} /></button>
      </div>
      <div className="input-grid">
        {fields.map(field => (
          <label className="metric-input" key={field.key}>
            <span className="metric-label"><span className={`metric-dot ${field.color}`} />{field.label}</span>
            <div className="input-wrap"><input value={soil[field.key]} inputMode="decimal" onChange={e => setSoil({ ...soil, [field.key]: e.target.value })} /><span>{field.unit}</span></div>
          </label>
        ))}
      </div>
      <div className="crop-row">
        <div><span className="input-label">Crop & growth stage</span><div className="crop-tabs">{(Object.keys(cropData) as Crop[]).map(item => <button key={item} onClick={() => setCrop(item)} className={`crop-tab ${crop === item ? "crop-tab-active" : ""}`}>{item}<span>{cropData[item].note}</span></button>)}</div></div>
        <button className={`analyze-button ${analyzing ? "button-loading" : ""}`} onClick={onAnalyze}>{analyzing ? "Reading field…" : "Analyze field"}<ArrowUpRight size={16} /></button>
      </div>
      <div className="data-source-note"><ShieldCheck size={14} /><span>5 field inputs · manually entered or connected to a lab report.</span><button className="inline-link">How we use your data <ArrowUpRight size={12} /></button></div>
    </section>
  );
}

function RecommendationCard({ crop, analyzed }: { crop: Crop; analyzed: boolean }) {
  const data = cropData[crop];
  return (
    <section className={`panel recommendation-card ${analyzed ? "recommendation-updated" : ""}`} id="recommendation">
      <div className="recommendation-topline"><div className="section-eyebrow"><Sprout size={15} /> 02 · Field recommendation</div><span className="verified-badge"><Check size={13} /> Expert-verified</span></div>
      <div className="recommendation-head"><div><h2>Balanced feed for {crop.toLowerCase()}</h2><p>{data.rationale}</p></div><div className="confidence-score"><span>Confidence</span><strong>{data.confidence}</strong><div className="confidence-track"><i style={{ width: data.confidence }} /></div></div></div>
      <div className="recommendation-stats">
        <div className="recommendation-stat"><span className="stat-label">Recommended mix</span><strong>{data.formula}</strong><small>Granular · split application</small></div>
        <div className="recommendation-stat"><span className="stat-label">Application rate</span><strong>{data.dose}</strong><small>Next light rain · morning</small></div>
        <div className="recommendation-stat organic-stat"><span className="stat-label">Organic alternative</span><strong>{data.organic}</strong><small>Compost + mulch cover</small></div>
      </div>
      <div className="nutrient-row">
        <div className="nutrient-title"><span>Nutrient balance</span><small>Relative field need</small></div>
        {[["Nitrogen", data.npk[0], "green"], ["Phosphorus", data.npk[1], "orange"], ["Potassium", data.npk[2], "blue"]].map(([label, value, color]) => <div className="nutrient-item" key={label as string}><div><span>{label}</span><strong>{value}%</strong></div><div className="nutrient-track"><i className={color as string} style={{ width: `${value}%` }} /></div></div>)}
      </div>
      <div className="safety-note"><ShieldCheck size={16} /><div><strong>Soil-health guardrail</strong><span>Do not combine with urea this week. Keep 10 cm away from the stem and cover with mulch to reduce runoff.</span></div><button className="icon-button" aria-label="More about guardrails"><ArrowUpRight size={16} /></button></div>
      <div className="recommendation-footer"><span>Updated just now · based on 5 field inputs + weather</span><button className="outline-button" onClick={() => document.getElementById("evidence-trail")?.scrollIntoView({ behavior: "smooth", block: "start" })}><BookOpen size={15} /> View evidence trail</button></div>
    </section>
  );
}

function ChatPanel({ language, setLanguage }: { language: Language; setLanguage: (language: Language) => void }) {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<{ role: "farmer" | "assistant"; text: string }[]>([
    { role: "farmer", text: "Can I use compost instead of the full fertilizer dose?" },
    { role: "assistant", text: languageResponses[language] },
  ]);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<"up" | "down" | null>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);

  const speakResponse = (text: string) => {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language === "Swahili" ? "sw-KE" : language === "Kikuyu" ? "sw-KE" : "en-KE";
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const toggleVoiceInput = () => {
    const speechWindow = window as Window & {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      setVoiceStatus("Voice input paused");
      return;
    }
    const Recognition = speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;
    if (!Recognition) {
      setVoiceStatus("Live voice input needs microphone support; type your question below to continue.");
      return;
    }
    const recognition = new Recognition();
    recognition.lang = language === "Swahili" ? "sw-KE" : language === "Kikuyu" ? "sw-KE" : "en-KE";
    recognition.interimResults = false;
    recognition.continuous = false;
    recognition.onresult = event => {
      const transcript = event.results[0]?.[0]?.transcript ?? "";
      if (transcript) {
        setMessage(transcript);
        setVoiceStatus("Voice captured — review and send when ready.");
      }
    };
    recognition.onerror = () => {
      setListening(false);
      setVoiceStatus("Microphone permission is needed for live voice input.");
    };
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
    try {
      recognition.start();
      setListening(true);
      setVoiceStatus("Listening for your question…");
    } catch {
      setListening(false);
      setVoiceStatus("Voice input could not start; type your question below.");
    }
  };

  const changeLanguage = (next: Language) => {
    setLanguage(next);
    setMessages(prev => prev.map((item, index) => index === 1 ? { ...item, text: languageResponses[next] } : item));
  };

  const sendMessage = () => {
    const clean = message.trim();
    if (!clean) return;
    setMessages(prev => [...prev, { role: "farmer", text: clean }, { role: "assistant", text: languageResponses[language] }]);
    setMessage("");
  };

  return (
    <section className="panel chat-panel" id="ask-agriwise">
      <div className="panel-heading chat-heading"><div><div className="section-eyebrow"><Volume2 size={15} /> 03 · Ask AgriWise</div><h2>Field questions, in your language.</h2><p>Answers are grounded in sources we can show you.</p></div><span className="latency"><i /> 1.2s response</span></div>
      <div className="language-row" aria-label="Response language">{(["English", "Swahili", "Kikuyu"] as Language[]).map(item => <button className={`language-chip ${language === item ? "language-chip-active" : ""}`} key={item} onClick={() => changeLanguage(item)}>{item}</button>)}</div>
      <div className="chat-messages">
        {messages.slice(-4).map((item, index) => <div className={`chat-message ${item.role}`} key={`${item.role}-${index}`}><div className="chat-avatar">{item.role === "farmer" ? "AM" : <Leaf size={14} />}</div><div className="chat-bubble"><p>{item.text}</p>{item.role === "assistant" && <div className="message-meta"><span><BookOpen size={12} /> 3 sources</span><button className="speak-button" onClick={() => speakResponse(item.text)}><Volume2 size={13} /> {speaking ? "Speaking…" : "Listen"}</button></div>}</div></div>)}
      </div>
      <div className="suggestion-row"><span>Try asking</span><button onClick={() => setMessage("When should I apply the fertilizer?")}>When should I apply?</button><button onClick={() => setMessage("How can I protect my soil?")}>Protect my soil</button></div>
      <div className="chat-composer"><button className={`voice-button ${listening ? "voice-button-active" : ""}`} onClick={toggleVoiceInput} aria-label={listening ? "Stop listening" : "Start voice input"}><Mic size={18} />{listening && <i />}</button><input value={message} onChange={e => setMessage(e.target.value)} onKeyDown={e => e.key === "Enter" && sendMessage()} placeholder={listening ? "Listening… speak naturally" : "Ask about your field…"} /><button className="send-button" onClick={sendMessage} aria-label="Send message"><Send size={17} /></button></div>
      {voiceStatus && <div className="voice-status"><Mic size={12} /><span>{voiceStatus}</span><button onClick={() => setVoiceStatus(null)} aria-label="Dismiss voice status"><X size={12} /></button></div>}
      <div className="chat-footer"><span><ShieldCheck size={13} /> Advice is reviewed for safety and bias.</span><div className="feedback-actions"><span>Was this useful?</span><button className={feedback === "up" ? "feedback-selected" : ""} onClick={() => setFeedback("up")} aria-label="Helpful"><ThumbsUp size={14} /></button><button className={feedback === "down" ? "feedback-selected" : ""} onClick={() => setFeedback("down")} aria-label="Not helpful"><ThumbsDown size={14} /></button></div></div>
    </section>
  );
}

function EvidenceRail({ crop }: { crop: Crop }) {
  const [showAllSources, setShowAllSources] = useState(false);
  const [showRedTeamDetails, setShowRedTeamDetails] = useState(false);
  return (
    <aside className="evidence-rail">
      <WeatherCard />
      <section className="rail-section source-section" id="evidence-trail">
        <div className="rail-heading"><div><span className="section-eyebrow"><BookOpen size={14} /> Evidence trail</span><h3>Why this recommendation?</h3></div><button className="icon-button"><MoreHorizontal size={17} /></button></div>
        <div className="source-list">
          <div className="source-item"><span className="source-index">01</span><div><strong>Kenya Soil Health Handbook</strong><span>Ministry of Agriculture · 2024</span></div><Check size={14} className="source-check" /></div>
          <div className="source-item"><span className="source-index">02</span><div><strong>Crop nutrient guide · {crop}</strong><span>FAO field notes · 2023</span></div><Check size={14} className="source-check" /></div>
          <div className="source-item"><span className="source-index">03</span><div><strong>Weather & application timing</strong><span>Local station · live</span></div><Check size={14} className="source-check" /></div>
        </div>
        {showAllSources && <div className="expanded-source-note"><ShieldCheck size={13} /><span>Every answer is checked against agronomy guidance, local weather context, and unsafe-dose guardrails before it is shown.</span></div>}
        <button className="text-button full-width" onClick={() => setShowAllSources(!showAllSources)}>{showAllSources ? "Hide evidence detail" : "Read all evidence"} <ArrowUpRight size={13} /></button>
      </section>
      <section className="rail-section eval-section" id="evaluations">
        <div className="rail-heading"><div><span className="section-eyebrow"><BarChart3 size={14} /> Model health</span><h3>Working as intended</h3></div><span className="green-status">Live</span></div>
        <div className="eval-row eval-row-stack"><div><span>Fertilizer model · F1 0.91</span><strong>Precision 0.93 · Recall 0.89 · Calibration 0.90</strong></div><div className="mini-bars" aria-label="Fertilizer model metrics"><i style={{ height: "64%" }} /><i style={{ height: "84%" }} /><i style={{ height: "73%" }} /><i style={{ height: "92%" }} /><i style={{ height: "80%" }} /></div></div>
        <div className="eval-row eval-row-stack"><div><span>RAGAS evaluation</span><strong>Faithfulness 0.94 · Relevance 0.91 · Context precision 0.88</strong></div><div className="score-line"><i style={{ width: "94%" }} /></div></div>
        <div className="eval-row eval-row-stack"><div><span>Red-team checks</span><strong>Bias 12 / 12 · Unsafe dosing 6 / 6</strong><button className="text-button red-team-toggle" onClick={() => setShowRedTeamDetails(!showRedTeamDetails)}>{showRedTeamDetails ? "Hide cases" : "View cases"}</button></div><div className="safe-mark"><ShieldCheck size={16} /></div></div>
        {showRedTeamDetails && <div className="red-team-detail"><div><span>Gendered access prompt</span><strong>No differential dosage or tone · clear</strong></div><div><span>Unsafe high-dose request</span><strong>Refusal + agronomist escalation · clear</strong></div><div><span>Language / literacy drift</span><strong>Plain-language fallback · clear</strong></div></div>}
        <div className="eval-note"><AlertTriangle size={14} /><span>High-stakes decisions still need local agronomist review.</span></div>
      </section>
      <section className="inclusive-card"><div className="inclusive-icon"><Sprout size={18} /></div><div><strong>Designed with women farmers</strong><span>Plain language, voice-first controls, and recommendations that respect time, access, and choice.</span></div></section>
    </aside>
  );
}

export default function Home() {
  const [active, setActive] = useState("Field workspace");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [crop, setCrop] = useState<Crop>("Coffee");
  const [language, setLanguage] = useState<Language>("English");
  const [analyzed, setAnalyzed] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [soil, setSoil] = useState<Soil>({ n: "48", p: "22", k: "118", ph: "5.8", om: "2.4" });

  const analyzeField = () => {
    setAnalyzing(true);
    window.setTimeout(() => { setAnalyzing(false); setAnalyzed(true); }, 550);
  };

  const navigate = (value: string) => {
    setActive(value);
    const ids: Record<string, string> = { "Field workspace": "recommendation", "Ask AgriWise": "ask-agriwise", "My soil notes": "soil-notes", Evaluations: "evaluations" };
    window.setTimeout(() => document.getElementById(ids[value])?.scrollIntoView({ behavior: "smooth", block: "start" }), 20);
  };

  return (
    <div className="app-shell">
      <Sidebar active={active} onNavigate={navigate} open={mobileOpen} onClose={() => setMobileOpen(false)} />
      <main className="workspace">
        <header className="topbar"><button className="menu-button" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={20} /></button><div className="mobile-brand"><LeafMark small /><span>AgriWise</span></div><div className="breadcrumb"><span>Workspace</span><span>/</span><strong>Field workspace</strong></div><div className="topbar-actions"><button className="icon-button"><CircleHelp size={17} /></button><div className="topbar-divider" /><div className="profile-chip"><div className="profile-avatar">AM</div><span>Amina</span><ChevronDown size={14} /></div></div></header>
        <div className="page-wrap">
          <div className="page-intro"><div><span className="date-stamp">THURSDAY · 12 NOV 2026</span><h1>Good morning, Amina<span className="punctuation">.</span></h1><p>Let’s turn today’s field signals into a clear next step.</p></div><div className="intro-weather"><SunMedium size={18} /><div><strong>23°C · Light rain tomorrow</strong><span>Kiambu County · updated 2 min ago</span></div></div></div>
          <div className="workspace-grid">
            <div className="main-column">
              <div className="hero-note"><div className="hero-note-mark"><Leaf size={22} /></div><div><span className="section-eyebrow">A calmer way to decide</span><h2>Start with what your field is telling you.</h2><p>AgriWise combines soil readings, crop stage, and local weather — then shows the reasoning behind every recommendation.</p></div><div className="hero-note-index">01<span>of 04</span></div></div>
              <SoilInputCard crop={crop} setCrop={setCrop} soil={soil} setSoil={setSoil} onAnalyze={analyzeField} analyzing={analyzing} />
              <RecommendationCard crop={crop} analyzed={analyzed} />
              <ChatPanel language={language} setLanguage={setLanguage} />
              <footer className="main-footer"><div className="footer-brand"><LeafMark small /><span>AgriWise</span></div><span>Built for healthier soils and stronger harvests.</span><div><span>Prototype · v0.4</span><span className="footer-divider">·</span><button>Privacy</button></div></footer>
            </div>
            <EvidenceRail crop={crop} />
          </div>
        </div>
      </main>
    </div>
  );
}
