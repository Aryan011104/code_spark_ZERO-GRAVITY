# AgriWise TODO

## Farmer workspace and soil-aware recommendations
- [x] Provide an AI-powered agricultural workspace for smallholder farmers with expert-verified, context-specific farming guidance.
- [x] Use soil data fields for NPK, pH, organic matter, crop type, and weather context to produce a crop-specific fertilizer recommendation.
- [x] Support crop scenarios for coffee, potato, and maize, with balanced fertilization, organic alternatives, and long-term soil health notes.
- [x] Make the recommendation explainable with visible dosage, confidence, “why this fits,” and a source trail.

## Multilingual chatbot and voice demonstration
- [x] Provide a RAG-style chatbot surface with a clear assistant answer, source chips, language selection, farmer feedback, and a voice-interface demonstration.
- [x] Demonstrate multiple languages and accessible controls for smallholder farmers, including a listening state and response latency indicator.

## Evaluation and responsible AI evidence
- [x] Include fertilizer ML model evaluation evidence with precision, recall, and calibration metrics.
- [x] Include RAGAS testing evidence for faithfulness, answer relevance, and context precision.
- [x] Include red-team testing evidence for bias and unsafe recommendations, with inclusive support for women farmers.
- [x] Surface reliable agricultural sources, farmer feedback, low response latency, and safety guardrails in the interface.

## Delivery and quality
- [x] Serve a synchronized `manus-routes.json` manifest for `/` and `/404`.
- [x] Keep the responsive experience usable on mobile and desktop with high-contrast labels, touch-friendly controls, and no dependency on external secrets.
- [ ] Connect the prototype surfaces to live RAG, real-time weather, multilingual speech, evaluation runners, and durable farmer feedback storage.
