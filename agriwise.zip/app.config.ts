export default {
  logoUrl: "https://cdn.simpleicons.org/leaflet/2c7a57",
};
