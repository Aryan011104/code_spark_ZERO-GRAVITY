# AgriWise implementation plan

## Product shape
AgriWise is a front-end-first prototype of an AI agricultural advisory workspace for smallholder farmers. The primary experience is a calm, practical field dashboard: the user can inspect live weather, select a crop, enter soil readings, generate an explainable fertilizer plan, ask a multilingual agronomy question, and inspect evaluation/safety evidence. The prototype uses local client state for fast, deterministic demonstrations while keeping the initialized Express/tRPC/Drizzle foundation available for future RAG, voice, and persistence integrations.

## Design direction

### Candidate styles
- **Field notebook / agronomy lab** — 0.06 probability: warm paper surfaces, dark soil ink, green growth accents, and data presented like a trusted field record.
- **Tropical utility dashboard** — 0.08 probability: brighter crop colors, denser controls, and a highly operational feel.
- **Quiet climate intelligence** — 0.04 probability: cool slate, mist, and a restrained scientific instrument aesthetic.

Chosen direction: **Field notebook / agronomy lab**.

- **Design Movement:** editorial field notebook meets modern climate-tech instrument panel.
- **Core Principles:** trust before novelty; data stays legible; recommendations always show their reasoning; accessibility is part of the product, not an add-on.
- **Color Philosophy:** deep soil ink (#24332f) anchors trust; leaf green (#2c7a57) signals healthy growth; turmeric/clay accents add warmth and draw attention to inputs without making the UI feel synthetic; parchment surfaces keep the tool approachable in low-bandwidth, outdoor contexts.
- **Layout Paradigm:** a left rail for orientation and an asymmetric main canvas: an input/recommendation workspace occupies the center, while a slim evidence column keeps weather, sources, and safety context in view.
- **Signature Elements:** leaf-mark wordmark; “field note” cards with thin ink rules; compact status pills that read like instrument labels.
- **Interaction Philosophy:** visible state changes, useful defaults, no hidden assumptions. Every recommendation includes a reason, a source trail, or a safety note. Controls support keyboard and touch targets.
- **Animation:** short, low-key transitions only: cards lift 2px on hover, recommendation meters fill gently, and live status dots pulse once per interval. Avoid motion that competes with reading or voice controls.
- **Typography System:** Fraunces for large editorial headings; DM Sans for UI, labels, data, and body copy. Type hierarchy uses wide line-height and high contrast instead of oversized UI chrome.
- **Brand Essence:** practical agronomy intelligence for the people who grow our food — grounded, explainable, inclusive.
- **Brand Voice:** clear, warm, never patronizing. Example lines: “Start with what your field is telling you.” and “Here’s the recommendation, and why it fits this plot.”
- **Wordmark & Logo:** the AgriWise wordmark is paired with a simple outlined leaf/seed mark made from two curved strokes and a soil baseline.
- **Signature Brand Color:** leaf green #2c7a57, used for primary actions and healthy/verified states.

## Implementation approach
- Replace the starter Home page with a single responsive workspace using React, wouter-compatible routing, lucide icons, and local state.
- Build reusable in-page regions: AppShell, Sidebar, WeatherStrip, SoilInputCard, RecommendationCard, ChatPanel, and EvaluationCard.
- Keep interactions functional in prototype form: crop switching updates recommendation values; “Analyze field” applies a deterministic recommendation; language chips alter the sample response; voice button toggles listening; chat input adds an assistant response; feedback buttons update evidence state.
- Create `public/manus-routes.json` with `/` and `/404` routes before the dev server starts.
- Keep the server health endpoint and initialized tRPC/auth plumbing intact; no external provider keys or live model calls are required for this visual prototype.
- Add root `app.config.ts` with a durable logo URL placeholder-free SVG data URL is avoided; use a stable icon URL only if one is available. The site itself uses the in-app mark.

## Project structure
- `client/src/pages/Home.tsx` — primary AgriWise workspace and prototype interactions.
- `client/src/index.css` — palette, typography imports, surface treatments, responsive layout, and micro-interactions.
- `client/src/App.tsx` — route switch and shared providers.
- `client/public/manus-routes.json` — route manifest for `/` and `/404`.
- `server/_core/index.ts` / `server/routers.ts` — existing API shell retained for future RAG/voice/model integrations.
- `drizzle/schema.ts` / `server/db.ts` — existing user foundation retained; domain persistence intentionally deferred for this prototype.

## Build workflow
Use the initialized `pnpm dev` service on port 3000, validate with `pnpm check` and `pnpm build`, confirm the route manifest returns JSON, and use the managed preview for visual inspection. Save the finished work as a checkpoint on the canonical branch; publication remains separate from preview/checkpoint.
